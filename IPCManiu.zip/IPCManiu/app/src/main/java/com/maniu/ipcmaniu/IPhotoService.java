package com.maniu.ipcmaniu;

import com.maniu.ipc.ClassId;

@ClassId("com.maniu.ipcmaniu.PhotoService")
public interface IPhotoService {
    String getPhoto();
}
